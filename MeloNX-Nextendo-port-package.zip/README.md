# MeloNX 2.7 × Nextendo Network — Step-by-Step Port Package

This package ports the **entire Nextendo Network client** (from
`Ryujinx-Nextendo`, the NextendoNetwork Ryujinx fork) into the **MeloNX 2.7**
iOS tree (`starforgejo.dev/projects/MeloNX`, branch `master`), while keeping
every MeloNX-specific feature intact:

* `com.apple.developer.kernel.increased-memory-limit` entitlement (in
  `src/MeloNX/MeloNX/MeloNX.entitlements`) — untouched, enabled by default in 2.7
* the 2.7 RAM-limit bypass / memory entitlement machinery — untouched
* the StikDebug JIT flow — untouched (see note below)
* Swift/iOS front end (`src/MeloNX`) — untouched

Everything Nextendo was merged **at the C# core level** (Ryujinx.HLE, .Common,
.Graphics.*, .Cpu, Horizon), which is exactly where Nextendo's code lives, so
the online features work for any game launched from the iOS app.

## What was ported (all 408 Nextendo commits since the upstream merge-base `deb5dca4`)

| Phase | Patch | Contents |
|---|---|---|
| 1 | `patches/0001-phase1-core-services-nextendo.patch` (~129k lines) | The whole online core: account system (`NextendoAccount`, BAAS `id_token` signing, NSA/PID mapping, `NextendoLoginApplet`), DNS-MITM hostname redirection (`TlsSniInjector`, `NextendoNetworkCheck`), friends (`friends:u`, `NextendoFriendProfile/FriendPage/FriendListDecoration`), presence & in-game status bar per game (`TitleIDs.CurrentApplication`, rich presence), server stack (deferred Bsd Poll, 0xF000 pointer buffer, `ServerBase` rework), BCAT/cloud saves (Olsc, `NextendoIslandSync`), news, MiiSync, virtual cards, Horizon services (Ovln, FriendService), tests |
| 2 | `patches/0002-phase2-graphics-cpu-audio-input.patch` | ARMeilleure/Cpu/Vulkan/OpenGL/audio/input fixes the fork ships (Vulkan reserved-bindings fixes for Smash, safe teardown `Liberer()`, MoltenVK init, `JitSupportDarwin`-class cache fixes relevant to Apple platforms, `PhysicalKey` input model) |
| 3 | `patches/0003-phase3-desktop-ui-qlaunch-assets.patch` | **QLaunch / HOME Menu**: the full Switch-style launcher (`NextendoHomeMenuWindow`, `QlaunchThemePage/SettingsPage`, themes, `AnimationWriter`, SARC/LYT parsing), friends & lobby windows, account picker, in-game notifications, Discord presence integration, `AppHost` lifecycle for applet exit, `MainWindowViewModel` save-sync hooks, locales in 20 languages, Nextendo assets |
| 4 | `patches/0004-phase4-root-build-files.patch` | Root build glue: `Directory.Packages.props` (Nextendo versions + MeloNX packages kept, LibHac pinned to MeloNX's `0.21.0-alpha.129`), `nuget.config` (starforgejo feed preserved), `.gitignore`, solution, `Directory.Build.props` (Release `DebugType=none`), docs |

Phases **must be applied in order 1→4**.

## Verification already done

* All four patches pass `git apply --check` **and** `git apply` cleanly,
  in order, against a pristine MeloNX 2.7 `master` tree
  (`starforgejo.dev/projects/MeloNX` @ `1370051` "Add Show Memory Usage to PerGameSettings").
* Merge was produced by a real git merge (MeloNX tree re-based onto
  Nextendo's upstream merge-base, then `git merge` of `Ryujinx-Nextendo/main`),
  with 48 conflict files resolved individually — including hand-merges of
  `ServerBase.cs` (MeloNX handle-snapshot fast path kept + Nextendo deferred-poll
  machinery grafted), `IpcService.cs`, `Sm/IUserInterface.cs`,
  `LdnMitmClient.cs` (MeloNX iOS interface-address path kept + Nextendo
  `ILdnNetworkProvider`/LanPlay transport), `Directory.Packages.props`, and
  `LanDiscovery.cs`.

## How to build your own IPA (macOS required — Xcode + Apple signing)

> An IPA cannot be compiled on Linux/CI without macOS: the app is built by
> Xcode out of `src/MeloNX/MeloNX.xcodeproj`, with the C# core compiled to a
> native AOT dylib by .NET (`src/Ryujinx.Library`, `PublishAot`, `ios-arm64`).

### Local build (exact steps)

1. macOS with Xcode 16+ and the **.NET 10 SDK** (see `global.json` → `10.0.301`).
2. Start from the MeloNX 2.7 tree and apply the patches:
   ```bash
   git clone https://starforgejo.dev/projects/MeloNX.git melonx-nextendo
   cd melonx-nextendo
   git am --3way /path/to/patches/*.patch     # or: git apply patches/*.patch
   dotnet restore                              # pulls NSec, Ryujinx.SDL3-CS, etc.
   ```
3. Open `src/MeloNX/MeloNX.xcodeproj` in Xcode, select the `MeloNX` scheme
   (the Xcode run phase invokes `dotnet publish` of `Ryujinx.Library` for
   `ios-arm64` and embeds `libRyujinx.dylib`), then
   **Product → Archive → Export (unsigned / Ad-hoc with your cert)** → `.ipa`.
4. Sideload the IPA (PlumeImpactor / SideStore / TrollStore). Install
   **StikDebug** and use it to grant JIT at runtime; MeloNX 2.7 already ships
   the increased-memory entitlement and its RAM-limit handling, and this port
   does not modify any of that.

### CI build (GitHub Actions, macos-15)

`.github/workflows/build-ipa.yml` in this package builds an **unsigned IPA**
(`CODE_SIGNING_ALLOWED=NO`) and uploads it as a workflow artifact. Unsigned
IPAs still need JIT via StikDebug (or a signing pass with your own cert/P12
before installing). Note MeloNX upstream uses Forgejo CI; the included
`.forgejo` workflows from the MeloNX tree are preserved, this adds a GH mirror
workflow you can drop into a GitHub mirror of the fork.

## What is NOT done / caveats (be honest before you build)

* **Not runtime-tested.** No iOS device/emulation run happened in this
  environment; the port is source-complete and patch-verified, not play-tested.
  First build may surface residual compile errors (most likely spots: the
  desktop `Ryujinx` Avalonia project paths that differ between trees —
  `Ryujinx.Ava.Common` references inside the ported UI files — and minor
  `TitleIDs`/config API drift). These are UI-shell-only; the HLE core merge is
  clean.
* The desktop `Ryujinx` Avalonia project in this tree exists for development;
  MeloNX's iOS app uses `Ryujinx.Library` + Swift and does **not** compile the
  Avalonia UI, so phase-3 desktop windows do not ship in the IPA — but the
  **account login applet, friends service, presence/status, DNS redirect and
  LDN all live in phases 1–2 (HLE core) and DO ship**.
* **StikDebug JIT** is a runtime enabler (on-device debugger attach), not a
  compile-time feature; nothing to merge — the package keeps MeloNX's JIT
  detection flow as-is.
* **QLaunch note**: QLaunch/HOME menu rendering is Avalonia-window based on
  desktop. In the iOS app the QLaunch *services* (applet management, themes
  assets, presence wiring) are present; a native SwiftUI HOME launcher is a
  future UI task.
* Nextendo attestation secrets: `src/Ryujinx/Common/NextendoAppSecrets.template.cs`
  is compiled in with a placeholder (the upstream `EnsureNextendoAppSecrets`
  build target copies it automatically). Official-build-only attestation keys
  are not included (they are baked by Nextendo's release pipeline); the
  emulator still works against Nextendo servers as a standard client.
* Set server endpoints via env/`nextendo_baas.pem` at runtime as documented in
  the Nextendo README (`NEXTENDO_SERVER_IP`, `NEXTENDO_NAT_IP`,
  `NEXTENDO_BAAS_SIGNING_KEY`), or let the built-in DNS-MITM defaults from the
  fork apply.

## Sources

* Nextendo client: https://github.com/NextendoNetwork/Ryujinx-Nextendo (org mirror `KKiiya/Ryujinx-Nextendo`, commit `11e3775`)
* MeloNX 2.7 tree: https://starforgejo.dev/projects/MeloNX (commit `1370051`)
* Upstream base: https://git.ryujinx.app/ryubing/ryujinx (merge-base `deb5dca4`)
* Server stack docs: https://github.com/NextendoNetwork/nextendo-docs
